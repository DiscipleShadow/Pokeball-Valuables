# Pokeball Valuables
### Author: DiscipleShadow
### Version: 1.0.1

#### This mod adds Pokeballs as a valuable item to the game.

# Changelog
### Version 1.0.0 Initial release.
### Version 1.0.1 Decimated the pokeball meshes to have less triangles in hopes of improving performance with multiplayer games.