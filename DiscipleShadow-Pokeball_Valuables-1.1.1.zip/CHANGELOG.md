# Changelog
### Version 1.0.0 Initial release.
### Version 1.0.1 Decimated the pokeball meshes to have less triangles in hopes of improving performance with multiplayer games.
### Version 1.1.0 Added The following Valuables
##### Lure Ball, Quick Ball, Net Ball, Nest Ball, Luxury Ball, Love Ball, Heavy Ball, Dive Ball, Heal Ball.
### Version 1.1.1 Recalculated the normals on the pokeballs so the shadows are correct.